import { cn } from "@/lib/utils";

type ContainerProps = React.HTMLAttributes<HTMLDivElement> & {
  /** "content" (1152px) for prose/sections, "wide" (1440px) for full-bleed sections. */
  width?: "content" | "wide";
  as?: keyof React.JSX.IntrinsicElements;
};

export function Container({
  width = "content",
  as: Tag = "div",
  className,
  ...props
}: ContainerProps) {
  return (
    <Tag
      className={cn(
        width === "content" ? "container-content" : "container-wide",
        className,
      )}
      {...props}
    />
  );
}
