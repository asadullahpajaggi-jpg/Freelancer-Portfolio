import Link from "next/link";
import { Container } from "@/components/ui/container";
import { navItems, siteConfig } from "@/config/site";

export function SiteFooter() {
  const year = new Date().getFullYear();
  const socialLinks = Object.entries(siteConfig.social).filter(
    (entry): entry is [string, string] => Boolean(entry[1]),
  );

  return (
    <footer className="border-t border-[var(--border)] bg-[var(--surface-muted)]">
      <Container
        width="wide"
        className="grid gap-10 py-[var(--spacing-section-sm)] sm:grid-cols-2 lg:grid-cols-4"
      >
        <div className="flex flex-col gap-3 sm:col-span-2 lg:col-span-1">
          <Link
            href="/"
            className="font-[family-name:var(--font-display)] text-lg font-medium text-[var(--foreground)]"
          >
            {siteConfig.name}
          </Link>
          <p className="max-w-xs text-sm text-[var(--foreground-muted)]">
            {siteConfig.description}
          </p>
        </div>

        <nav aria-label="Footer navigation" className="flex flex-col gap-2.5">
          <p className="text-sm font-medium text-[var(--foreground)]">Navigate</p>
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="link w-fit text-sm text-[var(--foreground-muted)]"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex flex-col gap-2.5">
          <p className="text-sm font-medium text-[var(--foreground)]">Services</p>
          <p className="text-sm text-[var(--foreground-muted)]">
            A full list of services will appear here once that page is built.
          </p>
          <Link
            href="/services"
            className="link w-fit text-sm text-[var(--foreground-muted)]"
          >
            View services
          </Link>
        </div>

        <div className="flex flex-col gap-2.5">
          <p className="text-sm font-medium text-[var(--foreground)]">Get in touch</p>
          <p className="text-sm text-[var(--foreground-muted)]">
            Have a project in mind? Reach out and let&apos;s talk about it.
          </p>
          <Link
            href="/contact"
            className="link w-fit text-sm text-[var(--foreground-muted)]"
          >
            Contact
          </Link>

          {socialLinks.length > 0 ? (
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-2">
              {socialLinks.map(([platform, url]) => (
                <a
                  key={platform}
                  href={url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="link w-fit text-sm text-[var(--foreground-muted)] capitalize"
                >
                  {platform}
                </a>
              ))}
            </div>
          ) : (
            <p className="mt-1 text-xs text-[var(--foreground-muted)]">
              Social links coming soon.
            </p>
          )}
        </div>
      </Container>

      <div className="border-t border-[var(--border)]">
        <Container width="wide" className="py-5 text-sm text-[var(--foreground-muted)]">
          © {year} {siteConfig.name}. All rights reserved.
        </Container>
      </div>
    </footer>
  );
}
