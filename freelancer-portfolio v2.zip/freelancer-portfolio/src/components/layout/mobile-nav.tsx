"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Container } from "@/components/ui/container";
import { cn } from "@/lib/utils";
import { navItems, siteConfig } from "@/config/site";

type MobileNavProps = {
  id: string;
  isOpen: boolean;
  onNavigate: () => void;
};

/**
 * Slides open below the header on small screens. Uses the CSS
 * grid-template-rows 0fr/1fr technique so the height animates smoothly
 * without measuring pixel heights in JS, and respects
 * prefers-reduced-motion via the global rule in globals.css.
 */
export function MobileNav({ id, isOpen, onNavigate }: MobileNavProps) {
  return (
    <div
      id={id}
      aria-hidden={!isOpen}
      className={cn(
        "grid overflow-hidden border-[var(--border)] transition-[grid-template-rows] duration-300 ease-[var(--ease-out-soft)] md:hidden",
        isOpen ? "grid-rows-[1fr] border-t" : "grid-rows-[0fr] border-t-0",
      )}
    >
      <div className="min-h-0">
        <Container width="wide">
          <nav aria-label="Mobile" className="flex flex-col gap-1 py-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={onNavigate}
                tabIndex={isOpen ? 0 : -1}
                className="link rounded-[var(--radius-sm)] px-2 py-3 text-base font-medium text-[var(--foreground)]"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex flex-col gap-3 border-t border-[var(--border)] py-4">
            <Button
              href={siteConfig.ctaHref}
              onClick={onNavigate}
              tabIndex={isOpen ? 0 : -1}
              className="w-full"
            >
              {siteConfig.ctaLabel}
            </Button>
          </div>
        </Container>
      </div>
    </div>
  );
}
