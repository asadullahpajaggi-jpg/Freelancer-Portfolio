import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Heading, Subtitle } from "@/components/ui/typography";
import { Section } from "@/components/ui/section";
import { PublicLayout } from "@/components/layout/public-layout";

/**
 * TEMPORARY placeholder. Per the project brief, the real homepage
 * (hero, services, portfolio, etc.) is built in a later phase, not
 * here. This route exists only so `npm run dev` / `npm run build`
 * have something to render and the site shell (header, footer, theme,
 * design system) is verifiable end to end. Replace this file entirely
 * when the "Home page" phase starts.
 */
export default function Home() {
  return (
    <PublicLayout>
      <Section>
        <div className="flex flex-col gap-8">
          <div className="flex flex-col gap-3">
            <p className="text-sm font-medium text-[var(--accent)]">
              Phase 2 — Public shell
            </p>
            <Heading as="h1">Header, footer, and design system are live</Heading>
            <Subtitle>
              This placeholder previews the site shell — navigation, mobile
              menu, theme toggle, and the shared button/card/typography
              system. It will be replaced by the real homepage in a later
              phase.
            </Subtitle>
          </div>

          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <Card>
              <CardHeader>
                <CardTitle>Typography</CardTitle>
                <CardDescription>Display + body type scale</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-[family-name:var(--font-display)] text-lg">
                  Aa — display face
                </p>
                <p className="mt-1 text-sm">Aa — body face</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Buttons</CardTitle>
                <CardDescription>Variant + size foundation</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                <Button size="sm">Primary</Button>
                <Button size="sm" variant="secondary">
                  Secondary
                </Button>
                <Button size="sm" variant="outline">
                  Outline
                </Button>
                <Button size="sm" variant="ghost">
                  Ghost
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Theme</CardTitle>
                <CardDescription>Light / dark, toggle in the header</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-[var(--foreground-muted)]">
                  Follows system preference until changed. Try the toggle in
                  the header or mobile menu — it persists across reloads.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </Section>
    </PublicLayout>
  );
}
